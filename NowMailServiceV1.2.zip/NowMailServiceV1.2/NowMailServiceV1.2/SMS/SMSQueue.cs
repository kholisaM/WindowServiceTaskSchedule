﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.SMS;
public class SMSQueue
{
    public string SmsQueueId { get; set; }
    public DateTime? CreateDate { get; set; }
    public bool? IsSent { get; set; }
    public DateTime? DateSent { get; set; }
    public string Message { get; set; }
    public string Recipient { get; set; }
    public string CreateUser { get; set; }
    public int? Delivered { get; set; }
}
