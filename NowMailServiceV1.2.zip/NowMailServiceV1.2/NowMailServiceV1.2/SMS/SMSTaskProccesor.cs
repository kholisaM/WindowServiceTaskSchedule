﻿using NowMailServiceV1._2.BO;
using NowMailServiceV1.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.SMS;
public class SMSTaskProccesor
{
    public async Task SendSms()
    {
        string QueueId = "";
        string Recipeint = "";
        SmsService smsService = new SmsService();
        try
        {
            //get email setting
            string username = "";
            string Pwd = "";
            string Url = "";
            string LastEmailSent = "";
            var settings = smsService.SMSSettings();
            username = settings.SMS_Username;
            Pwd = settings.SMS_Password;
            Url = settings.SMS_BaseURL.Replace("'", "");

            //get emails to be sent out 
            var sms = await smsService.GetSmsEnqueue();
            bl_Sms _Sms = new bl_Sms();
            foreach (var item in sms)
            {
                _Sms = new bl_Sms();
                QueueId = item.SmsQueueId;
                var sender = new SmsSender(username, Pwd, Url);
                if (!string.IsNullOrEmpty(item.Recipient))
                {
                    _Sms.to = item.Recipient;
                    _Sms.body = Regex.Replace(item.Message, " *,", ",").Replace(",", ", ");

                    string jsonString;
                    jsonString = JsonSerializer.Serialize(_Sms);

                    string myData = "{to: \"27814526965\", body:\"Hello Mr. Mjobo!\"}";
                    await sender.SendSmsRecipient(jsonString, QueueId);
                    //update email when sent
                    await smsService.UpdateSmsQueue(item.SmsQueueId);
                    await smsService.EventLog(item.Recipient, 1);
                    LastEmailSent = $"Sms Last Sent {DateTime.Now}";

                }
                Recipeint = item.Recipient;

            }

            await smsService.ServiceLog(LastEmailSent, "Successfull", "SmsService", "Success");
            await smsService.ServiceRegistry();

        }
        catch (Exception ex)
        {
            await smsService.LogError(QueueId, ex.ToString(), "", 0);
            await smsService.ServiceLog(ex.ToString(), "Failed", "SmsService", "Failed");
            // Console.WriteLine("Error!", ex.Message);

        }





        // Console.Read();
    }
}
