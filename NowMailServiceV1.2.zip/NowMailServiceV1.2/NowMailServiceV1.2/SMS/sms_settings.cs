﻿using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.SMS;
public class sms_settings
{
    [Key]
    public string SmsSetting_Id { get; set; }
    public string SMS_Username { get; set; }
    public string SMS_Password { get; set; }
    public string SMS_BaseURL { get; set; }
}
