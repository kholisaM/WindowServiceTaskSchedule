﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.SMS
{
    public class bl_Sms
    {
        public string to { get; set; }
        public string body { get; set; }
    }
}
