﻿using NowMailServiceV1.BO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.SMS
{
    public class SmsSender
    {
        // This URL is used for sending messages
        string _myURI = "";
        SmsService smsService;
        // change these values to match your own account
        string _myUsername = "";
        string _myPassword = "";

        // the details of the message we want to send
        //  string myData = "{to: \"1111111\", body:\"Hello Mr. Smith!\"}";

        public SmsSender(string myUsername, string myPassword, string myURI)
        {
            _myUsername = myUsername;
            _myPassword = myPassword;
            _myURI = myURI;
        }



        public async Task<bool> SendSmsRecipient(string myData, string QueueId)
        {
            smsService = new SmsService();
            // build the request based on the supplied settings
            var request = WebRequest.Create(_myURI);

            // supply the credentials
            request.Credentials = new NetworkCredential(_myUsername, _myPassword);
            request.PreAuthenticate = true;
            // we want to use HTTP POST
            request.Method = "POST";
            // for this API, the type must always be JSON
            request.ContentType = "application/json";

            // Here we use Unicode encoding, but ASCIIEncoding would also work
            var encoding = new UnicodeEncoding();
            var encodedData = encoding.GetBytes(myData);

            // Write the data to the request stream
            var stream = request.GetRequestStream();
            stream.Write(encodedData, 0, encodedData.Length);
            stream.Close();

            // try ... catch to handle errors nicely
            try
            {
                // make the call to the API
                var response = request.GetResponse();

                // read the response and print it to the console
                var reader = new StreamReader(response.GetResponseStream());
                // Console.WriteLine(reader.ReadToEnd());

            }
            catch (WebException ex)
            {
                // show the general message
                //Console.WriteLine("An error occurred:" + ex.Message);

                // print the detail that comes with the error
                var reader = new StreamReader(ex.Response.GetResponseStream());
                //Console.WriteLine("Error details:" + reader.ReadToEnd());
                await smsService.LogError(QueueId, "Error details:" + reader.ReadToEnd(), "", 0);
            }
            return true;
        }
    }

}
