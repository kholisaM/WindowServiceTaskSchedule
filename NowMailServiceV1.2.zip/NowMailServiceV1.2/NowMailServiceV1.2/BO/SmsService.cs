﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using NowMailServiceV1.Util;
using MySql.Data.MySqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;
using Org.BouncyCastle.Cms;
using NowMailServiceV1._2.SMS;
using Dapper.Contrib.Extensions;
using NowMailServiceV1._2.BO;
using NowMailServiceV1._2.Email;

namespace NowMailServiceV1.BO
{
    public class SmsService
    {
        public async Task UpdateSmsQueue(string Id)
        {
            try
            {

                using (var connection = new MySqlConnection(General.ConnectionString()))
                {
                    var param = new DynamicParameters();
                    param.Add("Id", Id);
                    param.Add("isSent", true);

                    var user = await connection.ExecuteAsync("sp_SmsQueue_U", param, commandType: CommandType.StoredProcedure);
                }

            }
            catch (Exception ex) { throw ex; }
        }

        public async Task<IEnumerable<SMSQueue>> GetSmsEnqueue()
        {
            try
            {

                using (var connection = new MySqlConnection(General.ConnectionString()))
                {

                    var param = new DynamicParameters();


                    var data = await connection.QueryAsync<SMSQueue>("sp_SMSEnqueue_L", param, commandType: CommandType.StoredProcedure);

                    return data.ToList();
                }

            }
            catch (Exception ex)
            {
                // log email error logs
                throw ex;
            }
        }

        public sms_settings SMSSettings()
        {
            try
            {
                SqlMapperExtensions.TableNameMapper = (type) => type.Name;
                using (var connection = new MySqlConnection(General.ConnectionString()))
                {

                    var smsSetting = connection.GetAll<sms_settings>();

                    return smsSetting.FirstOrDefault();
                };
               
            }
            catch (Exception ex) { throw ex; }
        }

        public async Task LogError(string EmailQueueId, string ErrorMessage, string Recipient, int RetryCount = 0)
        {
            try
            {

                using (var connection = new MySqlConnection(General.ConnectionString()))
                {
                    var param = new DynamicParameters();
                    param.Add("SmsErrorLog_Id", Guid.NewGuid().ToString().ToUpper());
                    param.Add("Recipient", Recipient);
                    param.Add("ErrorMessage", ErrorMessage);
                    param.Add("RetryCount", 0);
                    param.Add("NotifyAdmin", false);
                    var user = await connection.ExecuteAsync("sp_SMS_ErrorLog_S", param, commandType: CommandType.StoredProcedure);
                }

                
            }
            catch (Exception ex) { throw ex; }
        }

        public async Task EventLog(string smsto, int type)
        {
            try
            {

                using (var connection = new MySqlConnection(General.ConnectionString()))
                {
                    var param = new DynamicParameters();
                    param.Add("SmsEventLog_Id", Guid.NewGuid().ToString().ToUpper());
                    param.Add("Recipient", smsto);

                    var user = await connection.ExecuteAsync("sp_Sms_EventLog_S", param, commandType: CommandType.StoredProcedure);
                }
             
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task ServiceLog(string data, string message, string processName, string status)
        {
            try
            {


                using (var connection = new MySqlConnection(General.ConnectionString())) 
                {
                    var param = new DynamicParameters();
                    param.Add("ServiceId", Guid.NewGuid().ToString().ToUpper());
                    param.Add("Status", status);
                    param.Add("Data", data);
                    param.Add("Message", message);
                    param.Add("ProcessName", processName);
                    var user = await connection.ExecuteAsync("sp_ServiceLog_S", param, commandType: CommandType.StoredProcedure);
                }
                   
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public async Task ServiceRegistry()
        {
            try
            {
                SqlMapperExtensions.TableNameMapper = (type) => type.Name;
                using (var connection = new MySqlConnection(General.ConnectionString()))
                {

                    var service = new service_registry { Id = 1, LastRun = DateTime.Now, UpdateDate = DateTime.Now };
                    await connection.UpdateAsync<service_registry>(service);
                };
            }
            catch (Exception ex)
            {

                throw ex;
            }
           
        }


    }
}
