﻿using Dapper;
using Dapper.Contrib.Extensions;
using MySql.Data.MySqlClient;
using NowMailServiceV1._2.Email;
using NowMailServiceV1._2.SMS;
using NowMailServiceV1.Util;
using Org.BouncyCastle.Cms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.BO
{
    public class EmailService
    {
        public async Task UpdateEmailQueue(string Id)
        {
            try
            {


                using (var connection = new MySqlConnection(General.ConnectionString()))
                {
                    var param = new DynamicParameters();
                    param.Add("EID", Id);

                    var user = await connection.ExecuteAsync("sp_EmailEnqueue_U", param, commandType: CommandType.StoredProcedure);
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public async Task<IEnumerable<EmailQueue>> GetEmailsEnqueue()
        {
            try
            {

                using (var connection = new MySqlConnection(General.ConnectionString()))
                {
                    var param = new DynamicParameters();


                    var data = await connection.QueryAsync<EmailQueue>("sp_GetEmailEnqueue_L", param, commandType: CommandType.StoredProcedure);

                    return  data.ToList();
                }

            }
            catch (Exception ex)
            {
                // log email error logs
                throw ex;
            }
        }

        public email_setting EmailSettings()
        {
            try
            {

                using (var connection = new MySqlConnection(General.ConnectionString()))
                {
                   
                    var emailSetting = connection.GetAll<email_setting>();

                    return emailSetting.FirstOrDefault();
                };
                
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task LogError(string EmailQueueId, string ErrorMessage, DateTime? Updatedate, int RetryCount = 0)
        {
            try
            {


                var connection = new MySqlConnection(General.ConnectionString());

                var param = new DynamicParameters();
                param.Add("emailQueueId", Guid.NewGuid().ToString().ToUpper());
                param.Add("RetryCount", 0);
                param.Add("NotifiyAdmin", false);
                param.Add("ErrorMessage", ErrorMessage);
               
                var user = await connection.ExecuteAsync("sp_EmailEventErrorLog_S", param, commandType: CommandType.StoredProcedure);

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task EventLogError(string Emailto, int type)
        {
            try
            {
                using (var connection = new MySqlConnection(General.ConnectionString()))
                {
                    var param = new DynamicParameters();
                    param.Add("emailEventlog_id", Guid.NewGuid().ToString().ToUpper());
                    param.Add("Emailto", Emailto);
                    param.Add("emailtype", type);

                    var user = await connection.ExecuteAsync("sp_EmailEventLog_S", param, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task ServiceLog(string data, string message, string processName, string status)
        {
            try
            {

                using (var connection = new MySqlConnection(General.ConnectionString())) 
                {
                    var param = new DynamicParameters();
                    param.Add("ServiceId", Guid.NewGuid().ToString().ToUpper());
                    param.Add("Status", status);
                    param.Add("Data", data);
                    param.Add("Message", message);
                    param.Add("ProcessName", processName);
                    var user = await connection.ExecuteAsync("sp_ServiceLog_S", param, commandType: CommandType.StoredProcedure);
                }


            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task ServiceRegistry()
        {
            try
            {

                SqlMapperExtensions.TableNameMapper = (type) => type.Name;
                using (var connection = new MySqlConnection(General.ConnectionString()))
            {
             
                var service = new service_registry { Id = 2, LastRun = DateTime.Now, UpdateDate = DateTime.Now };
                await connection.UpdateAsync<service_registry>(service);
            };
            }
            catch (Exception ex) { throw ex; }
        }
    }
}
