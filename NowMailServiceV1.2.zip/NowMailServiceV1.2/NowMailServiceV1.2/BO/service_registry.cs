﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.BO;
internal class service_registry
{
    public int Id { get; set; }
    public DateTime LastRun { get; set; }
    public DateTime UpdateDate { get; set; }
}
