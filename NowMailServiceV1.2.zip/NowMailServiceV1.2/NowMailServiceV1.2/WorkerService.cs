﻿using NowMailServiceV1._2.Email;
using NowMailServiceV1._2.SMS;
using NowMailServiceV1.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace NowMailServiceV1._2;
public class WorkerService
{
    private readonly System.Timers.Timer _timer;
    private readonly EmailTaskProccesor _emailTaskProccesor;
    private readonly SMSTaskProccesor _sMSTaskProccesor;
    public WorkerService()
    {
        _timer = new System.Timers.Timer(5 * 60 * 1000) { AutoReset = true };
        _timer.Elapsed += TimerLapsed;
        _emailTaskProccesor = new EmailTaskProccesor();
        _sMSTaskProccesor = new SMSTaskProccesor();

    }

    private async void TimerLapsed(object sender, ElapsedEventArgs e)
    {
        //System.Configuration.ConfigurationManager.ConnectionStrings["MyDBConnectionString"].ConnectionString
        // throw new NotImplementedException();
        try
        {
            await _emailTaskProccesor.SendEmail();
            await _sMSTaskProccesor.SendSms();
        }
        catch (Exception ex)
        {
            General.EventLogInformation($"Error on TimerLapsed -  {ex}");
            
        }

    }
    public void Start()
    {
        try
        {

            _timer.Start();
            General.EventLogInformation($"Service has be started {DateTime.Now}");
        }
        catch (Exception ex)
        {
            General.EventLogInformation($"Error on start -  {ex}");
          
        }
    }
    public void Stop()
    {
        try
        {
            _timer.Stop(); General.EventLogInformation($"Service has been stopped {DateTime.Now}");
        }
        catch (Exception ex)
        {
            General.EventLogInformation($"Error on start -  {ex}");
            
        }
    }
}
