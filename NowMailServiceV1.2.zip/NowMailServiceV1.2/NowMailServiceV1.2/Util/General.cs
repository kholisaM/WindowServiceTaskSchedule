﻿using Google.Protobuf.WellKnownTypes;

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topshelf.Configurators;

namespace NowMailServiceV1.Util
{
    public class General
    {
        public static string ConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["MyDBConnectionString"].ConnectionString;

        }
        public static void EventLogInformation(string message)
        {
           
            using (EventLog eventLog = new EventLog("Application"))
            {
                eventLog.Source = "Application";
                eventLog.WriteEntry("NowMailCourier " + message, EventLogEntryType.Information, 101, 1);
            }
        }

  
    }
}
