﻿using NowMailServiceV1._2.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.Email;
public class EmailTaskProccesor
{

    public async Task SendEmail()
    {
        string EmailQueueId = "";
        EmailService emailService = new EmailService();
        try
        {

            //get email setting
            string mailUser = "";
            string mailUserPwd = "";

            var emailsettings = emailService.EmailSettings();
            mailUser = emailsettings.EmailSender;
            mailUserPwd = emailsettings.Password;

            //get emails to be sent out 
            var emails = await emailService.GetEmailsEnqueue();

            foreach (var item in emails)
            {
                EmailQueueId = item.Id;
                var sender = new EmailSender(mailUser, mailUserPwd);
                if (!string.IsNullOrEmpty(item.ToEmail))
                {
                    sender.SendMail(item.ToEmail, item.Subject, item.Template, item.Attachement);
                    //update email when sent
                    await emailService.UpdateEmailQueue(item.Id);
                    await emailService.EventLogError(item.ToEmail, 0);

                }
            }

            await emailService.ServiceLog("", "Successfull", "EmailService", "Success");
            await emailService.ServiceRegistry();
        }
        catch (Exception ex)
        {
            await emailService.LogError(EmailQueueId, ex.ToString(), DateTime.Now, 0);
            await emailService.ServiceLog(ex.ToString(), "Successfull", "EmailService", "Success");
        }

    }
}
