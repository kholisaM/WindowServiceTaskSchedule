﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.Email;
public class EmailSender
{
    string _sender = "";
    string _password = "";
    public EmailSender(string sender, string password)
    {
        _sender = sender;
        _password = password;
    }

    public void SendMail(string recipient, string subject, string message, string attachment = "")
    {
        SmtpClient client = new SmtpClient("smtp.nmprocessing.co.za");

        client.Port = 587;
        client.DeliveryMethod = SmtpDeliveryMethod.Network;
        client.UseDefaultCredentials = false;
        System.Net.NetworkCredential credentials =
            new System.Net.NetworkCredential(_sender, _password);
        client.EnableSsl = false;
        client.Credentials = credentials;

        try
        {
            var mail = new MailMessage(_sender.Trim(), recipient.Trim());

            if (!string.IsNullOrEmpty(attachment))
            {
                Attachment data = new Attachment(attachment);
                mail.Attachments.Add(data);
            }
            mail.Subject = subject;
            mail.Body = message;
            mail.IsBodyHtml = true;
            mail.BodyEncoding = Encoding.UTF8;
            client.Send(mail);
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }


}
