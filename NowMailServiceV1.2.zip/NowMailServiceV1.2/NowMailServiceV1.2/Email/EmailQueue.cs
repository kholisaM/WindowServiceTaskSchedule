﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NowMailServiceV1._2.Email;
public class EmailQueue
{
    public string DateSent { get; set; }
    public string IsSent { get; set; }
    public string FromEmail { get; set; }
    public string ToEmail { get; set; }
    public string Subject { get; set; }
    public string Body { get; set; }
    public string Template { get; set; }
    public string Attachement { get; set; }
    public string Id { get; set; }
}
