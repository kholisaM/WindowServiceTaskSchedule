﻿// See https://aka.ms/new-console-template for more information
using Google.Protobuf.WellKnownTypes;

using NowMailServiceV1._2;
using System.Configuration;
using Topshelf;
using Topshelf.Configurators;


var appSettings = ConfigurationManager.AppSettings;
var exitCode = HostFactory.Run(x =>
{
    x.Service<WorkerService>(s =>
    {
        s.ConstructUsing(workerService => new WorkerService());
        s.WhenStarted(workerService => workerService.Start());
        s.WhenStopped(workerService => workerService.Stop());
    });

    x.RunAsLocalService();
    x.SetServiceName(appSettings["ServiceName"]);
    x.SetDisplayName(appSettings["DisplayName"]);
    x.SetDescription(appSettings["Description"]);
});

int exitCodeValue = (int)Convert.ChangeType(exitCode, exitCode.GetTypeCode());
Environment.ExitCode = exitCodeValue;


